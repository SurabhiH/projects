from app import *

print("_"*20)
print("welcome to voteafternote ")
print("_"*20)
 

while True:
	print("\n","_"*20,"\n")

	print("what do u wanna do: \n\
		1.register \n\
		2.Create a voterid\n\
		3.Create a party\n\
		4.enroll to be a comittee member\n\
		5.enroll to be a president\n\
		6.cast ur vote\n\
		7.delete student record\n\
		8.delete party details\n\
		9.show party details\n\
		10.show results\n\
		11.exit")


	choice = input("-->")

	if choice =="1":
		create_info()

	elif choice =="2":
		create_voterid()

	elif choice =="3":
		create_party()

	elif choice =="4":
		enrollc()

	elif choice =="5":
		enrollp()

	elif choice =="6":
		cast()

	elif choice =="7":
		del_student()

	elif choice =="8":
		del_party()

	elif choice =="9":
		showparty()

	elif choice =="10":
		showresult()

	else:
		break


