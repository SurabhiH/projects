from peewee import *

db = SqliteDatabase('coll.db')



class Student(Model):
	studentname = CharField()
	password = CharField()
	branch = CharField()
	sem = IntegerField()


	class Meta:
		database = db

class Party(Model):
	partyname = CharField()
	no_of_candidates = IntegerField()
	president = CharField()
	is_successful = BooleanField()


	class Meta:
		database = db

class President(Model):
	party = ForeignKeyField(Party)
	name = CharField()
	branch = CharField()
	sem = IntegerField()


	class Meta:
		database = db


class Registration(Model):
	name = ForeignKeyField(Student)
	voter_id = CharField()


	class Meta:
		database = db

class Comittee(Model):
	name = ForeignKeyField(Student)
	party = ForeignKeyField(Party)
	branch = CharField()
	sem = IntegerField()



	class Meta:
		database = db

class Result(Model):
	year = DateTimeField()
	wonby = ForeignKeyField(Party)

	class Meta:
		database = db

class Votes(Model):
	studentname = ForeignKeyField(Student)
	voter_id = ForeignKeyField(Registration)
	party_id= ForeignKeyField(Party)
	president = ForeignKeyField(Party)
	
	class Meta:
		database = db


if __name__ == "__main__":
	db.connect()
	db.create_tables([Student,Party,President,Registration,Comittee,Result,Votes])
