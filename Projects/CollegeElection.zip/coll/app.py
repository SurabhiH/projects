from bottle import get,run,jinja2_view,post,request,redirect,response
from mod import *
from datetime import date
import random

db.connect()
	

def create_info():
	studentname = input("enter studentname:")
	users = Student.select().where(Student.studentname == studentname)
	if users.exists():
		print("studentname already exists")
		exit()
	password = input("enter password:")
	passw = Student.select().where(Student.password == password)
	if passw.exists():
		print("password already exists")
		exit()
	branch= input("enter the branch")
	sem = input("enter the sem")
	student = Student(studentname=studentname, password=password,branch=branch,sem=sem)
	student.save()
	print("student info entered successfully")



def create_voterid():
	name= input("enter studentname: ")
	user = Registration.select().where(Registration.name == name)
	if user.exists():
		print("please wait while ur voter_id is being generated")
	voterid = random.randint(0,100)
	print("voterid is" + str(voterid))
	vote = Registration.select().where(Registration.voter_id == voterid)
	if vote.exists():
		create_voterid()
	voter = Registration(name=name,voter_id=voterid)
	voter.save()
	return voterid



def create_party():
	partyname = input("enter partyname: ")
	par = Party.select().where(Party.partyname == partyname)
	if par.exists():
		print("party already exists")
		exit()
	no_of_candidates = input("enter the no_of_candidates: ")
	president= input("enter the president name: ")
	is_successful  = input("is it new?: ")
	party = Party(partyname=partyname, no_of_candidates=no_of_candidates,president=president,is_successful =is_successful)
	party.save()
	print("party created successfully")


def enrollc():
	name = input("enter studentname: ")
	party = input("enter partyname: ")
	par = Party.select().where(Party.partyname == party)
	if par.exists():
		pass
	else:
		print("no party exists")
		exit()
	sem =int(input("enter the sem of the student : "))
	if sem >=5:
		pass
	else:
		print("not eligible")
		exit()

	branch = input("enter the branch of student: ")

	en = Comittee(name=name,party=party,sem=sem,branch=branch)
	en.save()
	print ("enroled!")


def enrollp():
	party = input("enter partyname: ")
	par = Party.select().where(Party.partyname==party)
	if par.exists():
		pass
	else:
		print("no party as such exist")
		exit()
	name = input("enter the president: ")
	pre = Comittee.select().where(Comittee.name == name)
	if pre.exists():
		pass
	else:
		print("candidate not a member of party ")
		print("not eligible")
		exit()
	sem =int(input("enter the sem of the student: "))
	if sem >=7:
		pass
	else:
		print("not eligible")
		exit()

	branch = input("enter the branch of student: ")

	enp = Comittee(name=name,party=party,sem=sem,branch=branch)
	enp.save()
	print ("enroled!")


def cast():
	name=input("enter ur name")
	voter_id = input("enter ur voterid")
	print("please checkthe sheets provided to enter the correct partyname and president_name")
	partyname = input("enter the name of the party u wanna vote for")
	par = Party.select().where(Party.partyname == partyname)
	if not par.exists():
		print("party does not exists")
		exit()
	president = input("enter the name of the president from")
	print("thanks for voting")
	ca = Votes(studentname=name,voter_id=voter_id,party=partyname,president=president)
	ca.save()


def del_student():
	name = input("enter the student info to be deleted")
	delstu = Student.get(Student.studentname == name)
	delstu.delete_instance(recursive=True)
	print("entry deleted")

def del_party():
	partyname = input("enter the party info to be deleted")
	delparty = Party.get(Party.partyname == partyname)
	delparty.delete_instance(recursive=True)
	print("entry deleted")

def showparty():
	for p in Party.select():
		print(" partyname ",p.partyname ,"- president", p.president)


def showresult():
	for r in Votes:
		print("election won by : ",max(Votes.party_id))


