from gtts import gTTS
import os
mytext = "Welcome fellas!"
language = 'en'
myjobs = gTTS(text=mytext, lang=language,slow=True)
myjobs.save("Welcome.mp3")
os.system("Welcome.mp3")