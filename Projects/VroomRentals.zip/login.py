from tkinter import *
from tkinter import messagebox,ttk
from random import *
import tkinter as tk
import hashlib

def booking(name,booking_id):
    def dele():
        def delete_selected():
            del_list = list()
            del_list_1 = list()
            for i in tv.selection():
                deleting = tv.set(i, '#2')
                tv.delete(i)

                with open('book.txt', 'r') as file:
                    for line in file:
                        line = line.split('/')
                        del_list.append(line)

                    for i in del_list:
                        if deleting in i:
                            del_list.remove(i)
                        else:
                            continue

                    for j in del_list:
                        j = '/'.join(j)
                        del_list_1.append(j)

                    with open('book.txt', 'w') as file:
                        file.writelines(del_list_1)
                    print(del_list_1)

        username = user4.get()

        root5 = tk.Toplevel(root)
        root5.title("delete")
        booking_label = Label(root5, text="Previous Booking",justify=CENTER,font=('bold',15),padx=10,pady=10)
        booking_label.grid(row=1, column=1)
        frm = Frame(root5)
        frm.grid(row=2, column=1, padx=30, pady=20)

        tv = ttk.Treeview(frm, columns=(1, 2, 3, 4, 5,6),
                          show="headings", height="10")
        tv.grid(row=3, column=2)

        tv.heading(1, text="UserName", anchor=CENTER)
        tv.heading(2, text="Booking number", anchor=CENTER)
        tv.heading(3, text="DL Number", anchor=CENTER)
        tv.heading(4, text="Vehicle Type", anchor=CENTER)
        tv.heading(5, text="Pickup Date", anchor=CENTER)
        tv.heading(6, text="Drop Date", anchor=CENTER)

        with open('book.txt', 'r') as file:
            book_list = list()
            for line in file:
                line = line.split('/')

                book_list.append(line)

            for i in book_list:
                if username in i:
                    tv.insert('', 'end', values=i)
                else:
                    continue

        de = Button(root5,text="Delete",command=delete_selected,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=7,column=2)





    def u():
        def Bill1():
            root7 = tk.Toplevel(root)
            root7.geometry("1000x600")
            root7.title("Bill(updated)")

            username = user4.get()
            dlnum= dlno.get()
            vehicle1 = str(new_veh)
            pickup_date = pickup.get()
            drop_date = drop.get()
            Label(root7,text="""Your Booking on Vroom has been confirmed!
            Here's a copy of the bill which you will have to show to our staff when you come to collect our vehicle!""",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=0,column=1)
            Label(root7,text="Booking number: "+str(bookno),justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=1,column=1)
            Label(root7,text="Username: "+username,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=2,column=1)
            Label(root7,text="DL Number: "+dlnum,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=3,column=1)
            Label(root7,text="Vehicle: "+vehicle1,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=4,column=1)
            Label(root7,text="Pickup Date: "+pickup_date,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=5,column=1)
            Label(root7,text="Drop Date: "+drop_date,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=6,column=1)

            Label(root7,text="""NOTE""").grid(row=7,column=1)
            Label(root7,text="""Make sure to get your Original Driving license without fail when you come to collect the vehicle.
            Vehicle wont be handed unless the Original Driving license is verified by our staff.
            Make sure you follow all the traffic rules.
            Any fines (when the vehicle is in user's custody) regarding breaking of rules will have to be paid by the user.""",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=7,column=1)

            endd = Button(root7,text="Exit",command=root.quit,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=8,column=1)



        def check():
            global new_veh
            username = user4.get()

            new_book = str(bookno)
            new_veh = vehi.get()
            print(new_book)
            with open('book.txt','r') as f:
                blist1 = list()
                blist2 = list()
                for line in f:
                    line = line.split('/')
                    blist1.append(line)
                print(blist1)
                for i in blist1:
                    if new_book in i:
                        i[3] = str(new_veh)
                    else:
                        continue

                for j in blist1:
                    j = '/'.join(j)
                    blist2.append(j)
                print(blist2)

                with open('book.txt','w') as f:
                    f.writelines(blist2)
                Bill1()

        vehi = StringVar()
        vi = Label(root4,text="Change Your Vehicle Type",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row = 12,column = 1)
        vie = Entry(root4,textvariable=vehi).grid(row = 12,column = 2)



        Co = Button(root4,text="Confirm Changes",command=check,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row = 14,column = 2)

    def Bill():
        root6 = tk.Toplevel(root)
        root6.geometry("1000x600")
        root6.title("Bill")

        username = user4.get()
        dlnum= dlno.get()
        vehicle = veh.get()
        pickup_date = pickup.get()
        drop_date = drop.get()
        Label(root6,text="""Your Booking on Vroom has been confirmed!
        Here's a copy of the bill which you will have to show to our staff when you come to collect our vehicle!""",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=0,column=1)
        Label(root6,text="Booking number: "+str(bookno),justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=1,column=1)
        Label(root6,text="Username: "+username,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=2,column=1)
        Label(root6,text="DL Number: "+dlnum,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=3,column=1)
        Label(root6,text="Vehicle: "+vehicle,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=4,column=1)
        Label(root6,text="Pickup Date: "+pickup_date,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=5,column=1)
        Label(root6,text="Drop Date: "+drop_date,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=6,column=1)

        Label(root6,text="""NOTE""").grid(row=7,column=1)
        Label(root6,text="""Make sure to get your Original Driving license without fail when you come to collect the vehicle.
        Vehicle wont be handed unless the Original Driving license is verified by our staff.
        Make sure you follow all the traffic rules.
        Any fines (when the vehicle is in user's custody) regarding breaking of rules will have to be paid by the user.""",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=7,column=1)

        endd = Button(root6,text="Exit",command=root.quit,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=8,column=1)



    def upd():
        username = user4.get()

        dlnum= dlno.get()
        vehicle = veh.get()
        pickup_date = pickup.get()
        drop_date = drop.get()
        with open('book.txt','a') as file:
            file.write(username+'/')
            file.write(str(bookno)+'/')
            file.write(dlnum+'/')
            file.write(vehicle+'/')
            file.write(pickup_date+'/')
            file.write(drop_date+'/'+'\n')
        Bill()


    root4 = tk.Toplevel(root)
    root4.geometry('1100x600')
    root4.title('Booking')

    user4=StringVar()
    user = Label(root4,text="Enter Username:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=3,column=1)
    userE4 = Entry(root4,textvariable=user4).grid(row=3,column=2)

    bookno=randint(1000, 5000)
    Label(root4,text="Your Booking number is: "+str(bookno),justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=2,column=1)


    dlno = StringVar()
    dl = Label(root4,text="Enter DL Number :",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=4,column=1)
    dle = Entry(root4,textvariable=dlno).grid(row=4,column=2)

    veh = StringVar()
    ve =Label(root4,text="Vehicle Type (Gear/Non-Gear):",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=5,column=1)
    vee = Entry(root4,textvariable=veh).grid(row=5,column=2)

    pickup = StringVar()
    p = Label(root4,text="Enter the Date(DD-MM-YYYY)on which you want to pick the vehicle",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=6,column=1)
    pe =Entry(root4,textvariable=pickup).grid(row=6,column=2)

    drop = StringVar()
    d = Label(root4,text="Enter the Date(DD-MM-YYYY)on which you want to drop the vehicle",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=7,column=1)
    de = Entry(root4,textvariable=drop).grid(row=7,column=2)


    su= Button(root4,text="Submit",command=upd,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=16,column=1)

    sub= Button(root4,text="Update",command=u,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=16,column=2)

    do = Button(root4,text="Delete Booking",command=dele,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=16,column=3)




def Login():
    global pwd2
    global user2
    global bid

    root1 = tk.Toplevel(root)
    root1.geometry('400x300')
    root1.title('Login')

    user2=StringVar()
    user = Label(root1,text="Enter Username:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=3,column=1)
    userE2 = Entry(root1,textvariable=user2).grid(row=3,column=2)

    pwd2 = StringVar()
    pwd = Label(root1,text="Enter Password:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=4,column=1)
    pwdE2 = Entry(root1,textvariable=pwd2,show="*").grid(row=4,column=2)

    bid =StringVar()
    bookid = Label(root1,text="Enter Booking-ID:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=5,column=1)
    bidE = Entry(root1,textvariable=bid).grid(row=5,column=2)

    submit = Button(root1,text="Submit",command=Login_verify,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=7,column=2)


def Login_verify():
    with open("file.txt",'r') as f:
        password =  pwd2.get()
        print(password)
        name = user2.get()
        print(name)
        booking_id = bid.get()
        for line in f:
            line = line.rstrip()
            if re.search(name,line) and re.search(password, line) and re.search(booking_id, line):
                booking(name,booking_id)
                break
            else:
                continue
        else:
            messagebox.showerror('Error', 'Wrong Credentials')


def Register():
    root2 = tk.Toplevel(root)
    root2.geometry('400x400')
    root2.title("Register")

    def Register_verify():
        with open('file.txt','r') as f:
            p = pwd1.get()
            print("hash value of pas ="+str(hash(p)) )
            password= str(hash(p))
            print(password)
            name = user1.get()
            print(name)
            booking_id = bid1
            print(booking_id)
            cno1 = contact_no.get()
            print(cno1)

            for line in f:
                line = line.rstrip()
                if re.search(name,line):
                    messagebox.showinfo('Error','Username already exists!')
                    break
                else:
                    continue
            else:
                with open('file.txt','a')as file:
                    file.write(name+'/')
                    file.write(password + '/')
                    file.write(str(booking_id)+'/')
                    file.write(cno1+'/'+'\n')
                booking(name,booking_id)

    user1 = StringVar()
    us = Label(root2,text="Enter Username:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=3,column=1)
    userE1 = Entry(root2,textvariable=user1).grid(row=3,column=2)

    pwd1 = StringVar()
    pwd = Label(root2,text="Enter Password:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=4,column=1)
    pwdE1 = Entry(root2,textvariable=pwd1,show="*").grid(row=4,column=2)

    bid1 = randint(10000,50000)
    bookid = Label(root2,text="Your USER-ID is:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=5,column=1)
    bidE1 = Label(root2,text=bid1).grid(row=5,column=2)

    contact_no = StringVar()
    cno = Label(root2,text="Enter Contact_No :",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=6,column=1)
    cnoE1 = Entry(root2,textvariable=contact_no).grid(row=6,column=2)

    submit_1 = Button(root2, text='Submit', command=Register_verify,justify=CENTER,font=('bold',10),padx=10,pady=10)
    submit_1.grid(row=9, column=2)

def view_plan():
    global ro
    ro = tk.Toplevel(root)
    ro.configure(bg="#243B63")
    Label(ro,text=""" Welcom to VROOOM Rentals
                We at VROOM! provide bikes on daily basis!
                We charge RS:300 per day inclusive of 2 helmets!
                Once the user exceeds 24 hours, additional charge of Rs.50 per hour will be added.
                Any damage done to the vehicle under user's custody will have to be repaired by the user.
                The payment will be done in 2 installments.Based on the number of days the user books the vehicle,
                50% of the payment should be paid as first installment by the user when he/she arrives to pick the vehicle.
                The other 50% should be paid by the user with the additional charges if any.""",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=0,column = 1)
    Label(ro,text="For further queries you can contact our staff on call on the number listed in the main screen!",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=1,column = 1)
    bu = Button(ro,text="Proceed",font=('bold',15),padx=10,pady=10,command=can).grid(row = 3 ,column =1)

def can():
    ro.destroy()

def feed():
    def feed_verify():
        with open("file.txt",'r') as f:
            password =  p2.get()
            print(password)
            name = u2.get()
            print(name)
            booking_id = bd.get()
            for line in f:
                line = line.rstrip()
                if re.search(name,line) and re.search(password, line) and re.search(booking_id, line):
                    writefeed()
                    break
                else:
                    continue
            else:
                messagebox.showerror('Error', 'Wrong Credentials')

    global p2
    global u2
    global bid



    root8 = tk.Toplevel(root)
    root8.geometry('500x600')
    root8.title('Feedback')

    u2=StringVar()
    u = Label(root8,text="Enter Username:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=3,column=1)
    uE2 = Entry(root8,textvariable=u2).grid(row=3,column=2)

    p2 = StringVar()
    p = Label(root8,text="Enter Password:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=4,column=1)
    pE2 = Entry(root8,textvariable=p2,show="*").grid(row=4,column=2)

    bd =StringVar()
    bokid = Label(root8,text="Enter Booking-ID:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=5,column=1)
    bdE = Entry(root8,textvariable=bd).grid(row=5,column=2)

    submit = Button(root8,text="Submit",command=feed_verify,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=7,column=2)



def writefeed():

    def up():
        username = u2.get()
        feedbacks= fee.get()

        with open('feedback.txt','a') as file:
            file.write(username+'/')
            file.write(feedbacks+'/')
        main_screen()

    root9 = tk.Toplevel(root)
    root9.geometry('500x600')
    root9.title('Feedback')
    fee=StringVar()
    f = Label(root9,text="Please enter your feedback:",justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=4,column=1)
    fE2 = Entry(root9,textvariable=fee).grid(row=4,column=2)

    su= Button(root9,text="Submit",command=up,justify=CENTER,font=('bold',15),padx=10,pady=10).grid(row=16,column=1)




def main_screen():
    global root
    root = tk.Tk()
    root.geometry('1200x500')

    root.title("VROOM Bike rentalss")
    wel = Label(root, text="Welcome to VROOOM Bike Rentals!!!",justify=CENTER,font=('bold',20),padx=10,pady=10)
    wel.grid(row=1,column=1)
    cont = Label(root,text="Contact No:91234567890",font=('bold',15),padx=10,pady=10).grid(row=1, column=2,padx=10,pady=10)
    pla = Label(root,text="Please click below to view the plans",font=('bold',15),padx=10,pady=10).grid(row=2, column=0)
    plb = Button(root,text="Plans!",font=('bold',15),padx=10,pady=10,command=view_plan).grid(row=3, column=0)
    R = Label(root, text="If New User Click on Register!",font=('bold',15),padx=10,pady=10).grid(row=2, column=1)
    rb = Button(root, text="Register",command=Register,font=('bold',15),padx=30,pady=10).grid(row=2, column=2,padx=10,pady=10)
    L = Label(root, text="If Registered User Click on Login!",font=('bold',15),padx=10,pady=10).grid(row=4, column=1)
    lb = Button(root, text="Login",command=Login,font=('bold',15),padx=30,pady=10).grid(row=4, column=2,padx=10,pady=10)

    F = Label(root, text="Give us a FeedBack",font=('bold',15),padx=10,pady=10).grid(row=5, column=1)
    lb = Button(root, text="FeedBack",command=feed,font=('bold',15),padx=30,pady=10).grid(row=5, column=2,padx=10,pady=10)


    root.mainloop()

main_screen()
