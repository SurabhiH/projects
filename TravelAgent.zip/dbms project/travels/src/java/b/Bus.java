/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "bus")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bus.findAll", query = "SELECT b FROM Bus b")
    , @NamedQuery(name = "Bus.findByCustomerName", query = "SELECT b FROM Bus b WHERE b.customerName = :customerName")
    , @NamedQuery(name = "Bus.findByDestination", query = "SELECT b FROM Bus b WHERE b.destination = :destination")
    , @NamedQuery(name = "Bus.findByBusNo", query = "SELECT b FROM Bus b WHERE b.busNo = :busNo")
    , @NamedQuery(name = "Bus.findByNoOfSeats", query = "SELECT b FROM Bus b WHERE b.noOfSeats = :noOfSeats")
    , @NamedQuery(name = "Bus.findByPayment", query = "SELECT b FROM Bus b WHERE b.payment = :payment")})
public class Bus implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "customer_name")
    private String customerName;
    @Size(max = 25)
    @Column(name = "destination")
    private String destination;
    @Size(max = 15)
    @Column(name = "bus_no")
    private String busNo;
    @Size(max = 10)
    @Column(name = "no_of_seats")
    private String noOfSeats;
    @Size(max = 20)
    @Column(name = "payment")
    private String payment;

    public Bus() {
    }

    public Bus(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getBusNo() {
        return busNo;
    }

    public void setBusNo(String busNo) {
        this.busNo = busNo;
    }

    public String getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(String noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerName != null ? customerName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bus)) {
            return false;
        }
        Bus other = (Bus) object;
        if ((this.customerName == null && other.customerName != null) || (this.customerName != null && !this.customerName.equals(other.customerName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "b.Bus[ customerName=" + customerName + " ]";
    }
    
}
