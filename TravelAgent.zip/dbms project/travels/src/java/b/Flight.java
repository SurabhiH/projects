/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "flight")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Flight.findAll", query = "SELECT f FROM Flight f")
    , @NamedQuery(name = "Flight.findByCustomerName", query = "SELECT f FROM Flight f WHERE f.customerName = :customerName")
    , @NamedQuery(name = "Flight.findByFlightNo", query = "SELECT f FROM Flight f WHERE f.flightNo = :flightNo")
    , @NamedQuery(name = "Flight.findByArrival", query = "SELECT f FROM Flight f WHERE f.arrival = :arrival")
    , @NamedQuery(name = "Flight.findByDeparture", query = "SELECT f FROM Flight f WHERE f.departure = :departure")
    , @NamedQuery(name = "Flight.findByDestination", query = "SELECT f FROM Flight f WHERE f.destination = :destination")
    , @NamedQuery(name = "Flight.findByPayment", query = "SELECT f FROM Flight f WHERE f.payment = :payment")
    , @NamedQuery(name = "Flight.findByNoOfSeats", query = "SELECT f FROM Flight f WHERE f.noOfSeats = :noOfSeats")})
public class Flight implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "customer_name")
    private String customerName;
    @Size(max = 20)
    @Column(name = "flight_no")
    private String flightNo;
    @Column(name = "arrival")
    @Temporal(TemporalType.TIME)
    private Date arrival;
    @Column(name = "departure")
    @Temporal(TemporalType.TIME)
    private Date departure;
    @Size(max = 25)
    @Column(name = "destination")
    private String destination;
    @Size(max = 8)
    @Column(name = "payment")
    private String payment;
    @Size(max = 10)
    @Column(name = "no_of_seats")
    private String noOfSeats;

    public Flight() {
    }

    public Flight(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }

    public Date getArrival() {
        return arrival;
    }

    public void setArrival(Date arrival) {
        this.arrival = arrival;
    }

    public Date getDeparture() {
        return departure;
    }

    public void setDeparture(Date departure) {
        this.departure = departure;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(String noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerName != null ? customerName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flight)) {
            return false;
        }
        Flight other = (Flight) object;
        if ((this.customerName == null && other.customerName != null) || (this.customerName != null && !this.customerName.equals(other.customerName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "b.Flight[ customerName=" + customerName + " ]";
    }
    
}
