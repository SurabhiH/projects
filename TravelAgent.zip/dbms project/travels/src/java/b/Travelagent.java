/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "travelagent")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Travelagent.findAll", query = "SELECT t FROM Travelagent t")
    , @NamedQuery(name = "Travelagent.findByAgentname", query = "SELECT t FROM Travelagent t WHERE t.agentname = :agentname")
    , @NamedQuery(name = "Travelagent.findByAgentNumber", query = "SELECT t FROM Travelagent t WHERE t.agentNumber = :agentNumber")
    , @NamedQuery(name = "Travelagent.findByAgentAddress", query = "SELECT t FROM Travelagent t WHERE t.agentAddress = :agentAddress")})
public class Travelagent implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "agentname")
    private String agentname;
    @Size(max = 10)
    @Column(name = "agent_number")
    private String agentNumber;
    @Size(max = 20)
    @Column(name = "agent_address")
    private String agentAddress;

    public Travelagent() {
    }

    public Travelagent(String agentname) {
        this.agentname = agentname;
    }

    public String getAgentname() {
        return agentname;
    }

    public void setAgentname(String agentname) {
        this.agentname = agentname;
    }

    public String getAgentNumber() {
        return agentNumber;
    }

    public void setAgentNumber(String agentNumber) {
        this.agentNumber = agentNumber;
    }

    public String getAgentAddress() {
        return agentAddress;
    }

    public void setAgentAddress(String agentAddress) {
        this.agentAddress = agentAddress;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (agentname != null ? agentname.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Travelagent)) {
            return false;
        }
        Travelagent other = (Travelagent) object;
        if ((this.agentname == null && other.agentname != null) || (this.agentname != null && !this.agentname.equals(other.agentname))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "b.Travelagent[ agentname=" + agentname + " ]";
    }
    
}
