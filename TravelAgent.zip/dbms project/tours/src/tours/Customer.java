/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tours;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "customer", catalog = "mysql", schema = "")
@NamedQueries({
    @NamedQuery(name = "Customer.findAll", query = "SELECT c FROM Customer c")
    , @NamedQuery(name = "Customer.findByCustomerName", query = "SELECT c FROM Customer c WHERE c.customerName = :customerName")
    , @NamedQuery(name = "Customer.findByPhoneNo", query = "SELECT c FROM Customer c WHERE c.phoneNo = :phoneNo")
    , @NamedQuery(name = "Customer.findByEmail", query = "SELECT c FROM Customer c WHERE c.email = :email")
    , @NamedQuery(name = "Customer.findByAddress", query = "SELECT c FROM Customer c WHERE c.address = :address")
    , @NamedQuery(name = "Customer.findByDestination", query = "SELECT c FROM Customer c WHERE c.destination = :destination")
    , @NamedQuery(name = "Customer.findByDateOfArrival", query = "SELECT c FROM Customer c WHERE c.dateOfArrival = :dateOfArrival")
    , @NamedQuery(name = "Customer.findByDateOfDeparture", query = "SELECT c FROM Customer c WHERE c.dateOfDeparture = :dateOfDeparture")
    , @NamedQuery(name = "Customer.findByModeOfTravel", query = "SELECT c FROM Customer c WHERE c.modeOfTravel = :modeOfTravel")
    , @NamedQuery(name = "Customer.findByHotel", query = "SELECT c FROM Customer c WHERE c.hotel = :hotel")})
public class Customer implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "phone_no")
    private String phoneNo;
    @Column(name = "email")
    private String email;
    @Column(name = "address")
    private String address;
    @Column(name = "destination")
    private String destination;
    @Column(name = "date_of_arrival")
    private String dateOfArrival;
    @Column(name = "date_of_departure")
    private String dateOfDeparture;
    @Column(name = "mode_of_travel")
    private String modeOfTravel;
    @Column(name = "hotel")
    private String hotel;

    public Customer() {
    }

    public Customer(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        String oldCustomerName = this.customerName;
        this.customerName = customerName;
        changeSupport.firePropertyChange("customerName", oldCustomerName, customerName);
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        String oldPhoneNo = this.phoneNo;
        this.phoneNo = phoneNo;
        changeSupport.firePropertyChange("phoneNo", oldPhoneNo, phoneNo);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        String oldEmail = this.email;
        this.email = email;
        changeSupport.firePropertyChange("email", oldEmail, email);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        String oldAddress = this.address;
        this.address = address;
        changeSupport.firePropertyChange("address", oldAddress, address);
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        String oldDestination = this.destination;
        this.destination = destination;
        changeSupport.firePropertyChange("destination", oldDestination, destination);
    }

    public String getDateOfArrival() {
        return dateOfArrival;
    }

    public void setDateOfArrival(String dateOfArrival) {
        String oldDateOfArrival = this.dateOfArrival;
        this.dateOfArrival = dateOfArrival;
        changeSupport.firePropertyChange("dateOfArrival", oldDateOfArrival, dateOfArrival);
    }

    public String getDateOfDeparture() {
        return dateOfDeparture;
    }

    public void setDateOfDeparture(String dateOfDeparture) {
        String oldDateOfDeparture = this.dateOfDeparture;
        this.dateOfDeparture = dateOfDeparture;
        changeSupport.firePropertyChange("dateOfDeparture", oldDateOfDeparture, dateOfDeparture);
    }

    public String getModeOfTravel() {
        return modeOfTravel;
    }

    public void setModeOfTravel(String modeOfTravel) {
        String oldModeOfTravel = this.modeOfTravel;
        this.modeOfTravel = modeOfTravel;
        changeSupport.firePropertyChange("modeOfTravel", oldModeOfTravel, modeOfTravel);
    }

    public String getHotel() {
        return hotel;
    }

    public void setHotel(String hotel) {
        String oldHotel = this.hotel;
        this.hotel = hotel;
        changeSupport.firePropertyChange("hotel", oldHotel, hotel);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerName != null ? customerName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.customerName == null && other.customerName != null) || (this.customerName != null && !this.customerName.equals(other.customerName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "tours.Customer[ customerName=" + customerName + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
