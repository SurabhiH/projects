/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tours;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "bus", catalog = "mysql", schema = "")
@NamedQueries({
    @NamedQuery(name = "Bus.findAll", query = "SELECT b FROM Bus b")
    , @NamedQuery(name = "Bus.findByCustomerName", query = "SELECT b FROM Bus b WHERE b.customerName = :customerName")
    , @NamedQuery(name = "Bus.findByDestination", query = "SELECT b FROM Bus b WHERE b.destination = :destination")
    , @NamedQuery(name = "Bus.findByBusNo", query = "SELECT b FROM Bus b WHERE b.busNo = :busNo")
    , @NamedQuery(name = "Bus.findByNoOfSeats", query = "SELECT b FROM Bus b WHERE b.noOfSeats = :noOfSeats")
    , @NamedQuery(name = "Bus.findByPayment", query = "SELECT b FROM Bus b WHERE b.payment = :payment")})
public class Bus implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "destination")
    private String destination;
    @Column(name = "bus_no")
    private String busNo;
    @Column(name = "no_of_seats")
    private String noOfSeats;
    @Column(name = "payment")
    private String payment;

    public Bus() {
    }

    public Bus(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        String oldCustomerName = this.customerName;
        this.customerName = customerName;
        changeSupport.firePropertyChange("customerName", oldCustomerName, customerName);
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        String oldDestination = this.destination;
        this.destination = destination;
        changeSupport.firePropertyChange("destination", oldDestination, destination);
    }

    public String getBusNo() {
        return busNo;
    }

    public void setBusNo(String busNo) {
        String oldBusNo = this.busNo;
        this.busNo = busNo;
        changeSupport.firePropertyChange("busNo", oldBusNo, busNo);
    }

    public String getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(String noOfSeats) {
        String oldNoOfSeats = this.noOfSeats;
        this.noOfSeats = noOfSeats;
        changeSupport.firePropertyChange("noOfSeats", oldNoOfSeats, noOfSeats);
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        String oldPayment = this.payment;
        this.payment = payment;
        changeSupport.firePropertyChange("payment", oldPayment, payment);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerName != null ? customerName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bus)) {
            return false;
        }
        Bus other = (Bus) object;
        if ((this.customerName == null && other.customerName != null) || (this.customerName != null && !this.customerName.equals(other.customerName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "tours.Bus[ customerName=" + customerName + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
