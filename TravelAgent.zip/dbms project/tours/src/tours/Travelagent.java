/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tours;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "travelagent", catalog = "mysql", schema = "")
@NamedQueries({
    @NamedQuery(name = "Travelagent.findAll", query = "SELECT t FROM Travelagent t")
    , @NamedQuery(name = "Travelagent.findByAgentname", query = "SELECT t FROM Travelagent t WHERE t.agentname = :agentname")
    , @NamedQuery(name = "Travelagent.findByAgentNumber", query = "SELECT t FROM Travelagent t WHERE t.agentNumber = :agentNumber")
    , @NamedQuery(name = "Travelagent.findByAgentAddress", query = "SELECT t FROM Travelagent t WHERE t.agentAddress = :agentAddress")})
public class Travelagent implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "agentname")
    private String agentname;
    @Column(name = "agent_number")
    private String agentNumber;
    @Column(name = "agent_address")
    private String agentAddress;

    public Travelagent() {
    }

    public Travelagent(String agentname) {
        this.agentname = agentname;
    }

    public String getAgentname() {
        return agentname;
    }

    public void setAgentname(String agentname) {
        String oldAgentname = this.agentname;
        this.agentname = agentname;
        changeSupport.firePropertyChange("agentname", oldAgentname, agentname);
    }

    public String getAgentNumber() {
        return agentNumber;
    }

    public void setAgentNumber(String agentNumber) {
        String oldAgentNumber = this.agentNumber;
        this.agentNumber = agentNumber;
        changeSupport.firePropertyChange("agentNumber", oldAgentNumber, agentNumber);
    }

    public String getAgentAddress() {
        return agentAddress;
    }

    public void setAgentAddress(String agentAddress) {
        String oldAgentAddress = this.agentAddress;
        this.agentAddress = agentAddress;
        changeSupport.firePropertyChange("agentAddress", oldAgentAddress, agentAddress);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (agentname != null ? agentname.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Travelagent)) {
            return false;
        }
        Travelagent other = (Travelagent) object;
        if ((this.agentname == null && other.agentname != null) || (this.agentname != null && !this.agentname.equals(other.agentname))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "tours.Travelagent[ agentname=" + agentname + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
