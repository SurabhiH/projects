/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tours;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "flight", catalog = "mysql", schema = "")
@NamedQueries({
    @NamedQuery(name = "Flight.findAll", query = "SELECT f FROM Flight f")
    , @NamedQuery(name = "Flight.findByCustomerName", query = "SELECT f FROM Flight f WHERE f.customerName = :customerName")
    , @NamedQuery(name = "Flight.findByFlightNo", query = "SELECT f FROM Flight f WHERE f.flightNo = :flightNo")
    , @NamedQuery(name = "Flight.findByArrival", query = "SELECT f FROM Flight f WHERE f.arrival = :arrival")
    , @NamedQuery(name = "Flight.findByDeparture", query = "SELECT f FROM Flight f WHERE f.departure = :departure")
    , @NamedQuery(name = "Flight.findByDestination", query = "SELECT f FROM Flight f WHERE f.destination = :destination")
    , @NamedQuery(name = "Flight.findByPayment", query = "SELECT f FROM Flight f WHERE f.payment = :payment")
    , @NamedQuery(name = "Flight.findByNoOfSeats", query = "SELECT f FROM Flight f WHERE f.noOfSeats = :noOfSeats")})
public class Flight implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "flight_no")
    private String flightNo;
    @Column(name = "arrival")
    @Temporal(TemporalType.TIME)
    private Date arrival;
    @Column(name = "departure")
    @Temporal(TemporalType.TIME)
    private Date departure;
    @Column(name = "destination")
    private String destination;
    @Column(name = "payment")
    private String payment;
    @Column(name = "no_of_seats")
    private String noOfSeats;

    public Flight() {
    }

    public Flight(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        String oldCustomerName = this.customerName;
        this.customerName = customerName;
        changeSupport.firePropertyChange("customerName", oldCustomerName, customerName);
    }

    public String getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(String flightNo) {
        String oldFlightNo = this.flightNo;
        this.flightNo = flightNo;
        changeSupport.firePropertyChange("flightNo", oldFlightNo, flightNo);
    }

    public Date getArrival() {
        return arrival;
    }

    public void setArrival(Date arrival) {
        Date oldArrival = this.arrival;
        this.arrival = arrival;
        changeSupport.firePropertyChange("arrival", oldArrival, arrival);
    }

    public Date getDeparture() {
        return departure;
    }

    public void setDeparture(Date departure) {
        Date oldDeparture = this.departure;
        this.departure = departure;
        changeSupport.firePropertyChange("departure", oldDeparture, departure);
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        String oldDestination = this.destination;
        this.destination = destination;
        changeSupport.firePropertyChange("destination", oldDestination, destination);
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        String oldPayment = this.payment;
        this.payment = payment;
        changeSupport.firePropertyChange("payment", oldPayment, payment);
    }

    public String getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(String noOfSeats) {
        String oldNoOfSeats = this.noOfSeats;
        this.noOfSeats = noOfSeats;
        changeSupport.firePropertyChange("noOfSeats", oldNoOfSeats, noOfSeats);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerName != null ? customerName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flight)) {
            return false;
        }
        Flight other = (Flight) object;
        if ((this.customerName == null && other.customerName != null) || (this.customerName != null && !this.customerName.equals(other.customerName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "tours.Flight[ customerName=" + customerName + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
