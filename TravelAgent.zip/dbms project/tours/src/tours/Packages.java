/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tours;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "packages", catalog = "mysql", schema = "")
@NamedQueries({
    @NamedQuery(name = "Packages.findAll", query = "SELECT p FROM Packages p")
    , @NamedQuery(name = "Packages.findByPackageName", query = "SELECT p FROM Packages p WHERE p.packageName = :packageName")
    , @NamedQuery(name = "Packages.findByCustomerName", query = "SELECT p FROM Packages p WHERE p.customerName = :customerName")
    , @NamedQuery(name = "Packages.findByModeOfTravel", query = "SELECT p FROM Packages p WHERE p.modeOfTravel = :modeOfTravel")
    , @NamedQuery(name = "Packages.findByArrival", query = "SELECT p FROM Packages p WHERE p.arrival = :arrival")
    , @NamedQuery(name = "Packages.findByDeparture", query = "SELECT p FROM Packages p WHERE p.departure = :departure")
    , @NamedQuery(name = "Packages.findByDestinaton", query = "SELECT p FROM Packages p WHERE p.destinaton = :destinaton")})
public class Packages implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "package_name")
    private String packageName;
    @Id
    @Basic(optional = false)
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "mode_of_travel")
    private String modeOfTravel;
    @Column(name = "arrival")
    private String arrival;
    @Column(name = "departure")
    private String departure;
    @Column(name = "destinaton")
    private String destinaton;

    public Packages() {
    }

    public Packages(String customerName) {
        this.customerName = customerName;
    }

    public Packages(String customerName, String packageName) {
        this.customerName = customerName;
        this.packageName = packageName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        String oldPackageName = this.packageName;
        this.packageName = packageName;
        changeSupport.firePropertyChange("packageName", oldPackageName, packageName);
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        String oldCustomerName = this.customerName;
        this.customerName = customerName;
        changeSupport.firePropertyChange("customerName", oldCustomerName, customerName);
    }

    public String getModeOfTravel() {
        return modeOfTravel;
    }

    public void setModeOfTravel(String modeOfTravel) {
        String oldModeOfTravel = this.modeOfTravel;
        this.modeOfTravel = modeOfTravel;
        changeSupport.firePropertyChange("modeOfTravel", oldModeOfTravel, modeOfTravel);
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        String oldArrival = this.arrival;
        this.arrival = arrival;
        changeSupport.firePropertyChange("arrival", oldArrival, arrival);
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        String oldDeparture = this.departure;
        this.departure = departure;
        changeSupport.firePropertyChange("departure", oldDeparture, departure);
    }

    public String getDestinaton() {
        return destinaton;
    }

    public void setDestinaton(String destinaton) {
        String oldDestinaton = this.destinaton;
        this.destinaton = destinaton;
        changeSupport.firePropertyChange("destinaton", oldDestinaton, destinaton);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerName != null ? customerName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Packages)) {
            return false;
        }
        Packages other = (Packages) object;
        if ((this.customerName == null && other.customerName != null) || (this.customerName != null && !this.customerName.equals(other.customerName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "tours.Packages[ customerName=" + customerName + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
