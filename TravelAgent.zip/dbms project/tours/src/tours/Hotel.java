/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tours;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author SINDHU
 */
@Entity
@Table(name = "hotel", catalog = "mysql", schema = "")
@NamedQueries({
    @NamedQuery(name = "Hotel.findAll", query = "SELECT h FROM Hotel h")
    , @NamedQuery(name = "Hotel.findByCustomerName", query = "SELECT h FROM Hotel h WHERE h.customerName = :customerName")
    , @NamedQuery(name = "Hotel.findByDestination", query = "SELECT h FROM Hotel h WHERE h.destination = :destination")
    , @NamedQuery(name = "Hotel.findByAddress", query = "SELECT h FROM Hotel h WHERE h.address = :address")
    , @NamedQuery(name = "Hotel.findByNoOfRooms", query = "SELECT h FROM Hotel h WHERE h.noOfRooms = :noOfRooms")
    , @NamedQuery(name = "Hotel.findByCheckIn", query = "SELECT h FROM Hotel h WHERE h.checkIn = :checkIn")
    , @NamedQuery(name = "Hotel.findByCheckOut", query = "SELECT h FROM Hotel h WHERE h.checkOut = :checkOut")})
public class Hotel implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "destination")
    private String destination;
    @Column(name = "address")
    private String address;
    @Column(name = "no_of_rooms")
    private String noOfRooms;
    @Column(name = "check_in")
    private String checkIn;
    @Column(name = "check_out")
    private String checkOut;

    public Hotel() {
    }

    public Hotel(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        String oldCustomerName = this.customerName;
        this.customerName = customerName;
        changeSupport.firePropertyChange("customerName", oldCustomerName, customerName);
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        String oldDestination = this.destination;
        this.destination = destination;
        changeSupport.firePropertyChange("destination", oldDestination, destination);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        String oldAddress = this.address;
        this.address = address;
        changeSupport.firePropertyChange("address", oldAddress, address);
    }

    public String getNoOfRooms() {
        return noOfRooms;
    }

    public void setNoOfRooms(String noOfRooms) {
        String oldNoOfRooms = this.noOfRooms;
        this.noOfRooms = noOfRooms;
        changeSupport.firePropertyChange("noOfRooms", oldNoOfRooms, noOfRooms);
    }

    public String getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(String checkIn) {
        String oldCheckIn = this.checkIn;
        this.checkIn = checkIn;
        changeSupport.firePropertyChange("checkIn", oldCheckIn, checkIn);
    }

    public String getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(String checkOut) {
        String oldCheckOut = this.checkOut;
        this.checkOut = checkOut;
        changeSupport.firePropertyChange("checkOut", oldCheckOut, checkOut);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerName != null ? customerName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hotel)) {
            return false;
        }
        Hotel other = (Hotel) object;
        if ((this.customerName == null && other.customerName != null) || (this.customerName != null && !this.customerName.equals(other.customerName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "tours.Hotel[ customerName=" + customerName + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
